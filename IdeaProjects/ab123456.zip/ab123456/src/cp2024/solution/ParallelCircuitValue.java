package cp2024.solution;

import cp2024.circuit.CircuitValue;

public class ParallelCircuitValue implements CircuitValue {
    @Override
    public boolean getValue() throws InterruptedException {
        /* FIX ME */
        throw new RuntimeException("Not implemented.");
    }
}
