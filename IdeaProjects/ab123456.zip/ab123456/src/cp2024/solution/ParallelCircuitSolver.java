package cp2024.solution;

import cp2024.circuit.CircuitSolver;
import cp2024.circuit.CircuitValue;
import cp2024.circuit.Circuit;

public class ParallelCircuitSolver implements CircuitSolver {
    @Override
    public CircuitValue solve(Circuit c) {
        /* FIX ME */
        throw new RuntimeException("Not implemented.");
    }

    @Override
    public void stop() {
        /*FIX ME*/
        throw new RuntimeException("Not implemented.");
    }
}
