package cp2024.solution;

public record PositionBoolean(
        Boolean bool1,  // for the result of solver
        Integer num     // for the position in array
) {
}
