package cp2024.circuit;

public enum NodeType {
    LEAF, GT, LT, AND, OR, NOT, IF
}
