package pl.edu.mimuw.expression;

public class Addition extends BinaryExpression{

    public Addition(Expression firstExpression,Expression secondExpression) {
        super(firstExpression,secondExpression);
    }

    @Override
    public double evaluate(double var) {
        return firstExpression.evaluate(var) + secondExpression.evaluate(var);
    }

    @Override
    public String toString() {
        return firstExpression.toString() + " + " + secondExpression.toString();
    }
}
