package pl.edu.mimuw.expression;

import java.lang.Math;

public class Sin extends OneArgumentFunction{

    public Sin(Expression functionExpression) {
        super(functionExpression);
    }

    @Override
    public double evaluate(double variable) {
        return Math.sin(functionExpression.evaluate(variable));
    }

    @Override
    public String toString() {
        return "sin(" + functionExpression.toString() + ")";
    }
}
