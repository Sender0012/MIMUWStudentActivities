package pl.edu.mimuw.expression;

public abstract class OneArgumentFunction extends Expression {

    protected final Expression functionExpression;

    public OneArgumentFunction(Expression functionExpression) {
        this.functionExpression = functionExpression;
    }

}

