package pl.edu.mimuw.expression;

public class FunctionNegation extends OneArgumentFunction {

    public FunctionNegation(Expression functionExpression) {
        super(functionExpression);
    }
    @Override
    public String toString() {
        return "-(" + functionExpression.toString() + ')';
    }

    @Override
    public double evaluate(double variable) {
        return functionExpression.evaluate(variable) * (-1);
    }
}
