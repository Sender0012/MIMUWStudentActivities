package pl.edu.mimuw;

import pl.edu.mimuw.expression.*;

public class Main {

    public static void main(String[] args) {
        double value = 3;

        Expression var1 = new Variable(2);
        System.out.println("Variable :");
        System.out.println(var1.toString());
        System.out.println(var1.evaluate(0.5));

        Expression con1 = new Constant(2);
        System.out.println("Const :");
        System.out.println(con1.evaluate(value));
        System.out.println(con1.toString());

        Expression add = new Addition(var1,con1);
        System.out.println("Adding :");
        System.out.println(add.toString());
        System.out.println(add.evaluate(value));

        Expression negate = new FunctionNegation(add);
        System.out.println("Function negation :");
        System.out.println(negate.toString());
        System.out.println(negate.evaluate(value));

        Expression sin = new Sin(negate);
        System.out.println("Function sin :");
        System.out.println(sin.toString());
        System.out.println(sin.evaluate(value));
    }
}
