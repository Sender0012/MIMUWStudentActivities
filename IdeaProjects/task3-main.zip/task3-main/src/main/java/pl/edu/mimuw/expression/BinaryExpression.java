package pl.edu.mimuw.expression;

abstract public class BinaryExpression extends Expression{

    protected final Expression firstExpression;
    protected final Expression secondExpression;

    public BinaryExpression(Expression firstExpression, Expression secondExpression) {
        this.firstExpression = firstExpression;
        this.secondExpression = secondExpression;
    }

}
