package pl.edu.mimuw.expression;

public class Variable extends Expression {
    private double multiplier;

    public Variable(double multiplier) {
        this.multiplier = multiplier;
    }

    @Override
    public double evaluate(double variable) {
        return multiplier * variable;
    }

    @Override
    public String toString() {
        return String.valueOf(multiplier)+'x';
    }
}
