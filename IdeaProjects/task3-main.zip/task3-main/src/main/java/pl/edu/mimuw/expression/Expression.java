package pl.edu.mimuw.expression;

abstract public class Expression {

    abstract public double evaluate(double variable);

}
