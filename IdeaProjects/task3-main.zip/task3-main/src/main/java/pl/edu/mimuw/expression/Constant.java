package pl.edu.mimuw.expression;

public class Constant extends Expression{

    private final double value ;

    public Constant(double expression){
        value = expression;
    }

    @Override
    public double evaluate(double variable) {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
